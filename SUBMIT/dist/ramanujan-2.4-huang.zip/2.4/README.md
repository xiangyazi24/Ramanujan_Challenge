# Problem 2.4 — harmonic numbers, polylogarithms and zeta values

**Status: partial. The problem statement is not proved.** Six of the seven scalar
evaluations its reduction requires are proved in Lean and are axiom-clean; the
seventh is open. This README states exactly which.

## Contents

- `solution.pdf` / `solution.tex` — the mathematical write-up (5 pages).
- `lean/RamanujanChallenge/` — four Lean 4 source files.

## What is proved

The double sum is reduced to seven scalar series of weight at most four. Writing
`P_m = H_m + 2·Σ_{k<m} (-1)^{k+1}/(k+1)`, so that `P_{2m} = 2H_m − H_{2m}` is the
harmonic remainder of the creative-telescoping certificate, and `Z_r = ζ(r)`,
`L = log 2`:

| series | status |
|---|---|
| `Σ (-1)^m (P_m² − H_m^{(2)})/m²` | **proved** |
| `Σ P_m/m³` | **proved** |
| `Σ (-1)^m P_m/m³` | **proved** |
| shifted linear Euler sum | **proved** |
| `Σ [2·(n⁴C(2n,n))⁻¹ − (3/2)·H_{n-1}^{(2)}(n²C(2n,n))⁻¹]` (Leshchiner) | **proved** |
| `Σ [3·(n⁴C(2n,n))⁻¹ − 9·H_{n-1}^{(2)}(n²C(2n,n))⁻¹]` (BBB) | **proved** |
| `Σ (P_m² − H_m^{(2)})/m²` | **OPEN** |

The certificate `problem24_of_euler_and_classical` takes these seven as
hypotheses. Feeding it the six proved ones leaves exactly one, and that
application typechecks — so there is no further hidden obligation, but the
challenge statement itself is not derived here.

Two of the proved evaluations are, as far as we know, new in this form: the
weight-four alternating quadratic Euler sum

```
Σ_{m≥1} (-1)^m (P_m² − H_m^{(2)})/m²
  = −22 Li₄(½) − (11/12) log⁴2 − (13/2) log²2 ζ(2) − (7/4) log2 ζ(3) + (67/10) ζ(2)²
```

and the reduction of the two inverse-central-binomial boundary sums to the pair
`Σ n⁻⁴C(2n,n)⁻¹ = 17π⁴/3240` (classical) and
`Σ H_{n-1}^{(2)} n⁻²C(2n,n)⁻¹ = 5π⁴/9720`.

## What is not proved

`Σ_{m≥1} (P_m² − H_m^{(2)})/m²`, the non-alternating companion of the first row.
Its value is `20 Li₄(½) + (5/6) log⁴2 + 7 log²2 ζ(2) − (59/10) ζ(2)²`, verified
numerically but not formalized. It is not the alternating case with a sign
changed: the generating function `Q(x) = 2J(x)/(1−x)` has a pole at `x = 1` which
the alternating chain, running the argument through `(−1,0)`, never meets.

## Verification

Toolchain `leanprover/lean4:v4.29.0`, Mathlib pinned in `lake-manifest.json`.
The four files contain **no `sorry`** and introduce **no axiom**. Every theorem
named above depends only on `propext`, `Classical.choice`, `Quot.sound`.

The Lean sources are provided as the development they were written in; building
them requires the accompanying `lakefile.toml`, `lean-toolchain` and
`lake-manifest.json` in `lean/`, and the file
`RamanujanChallenge/Problem24QuadraticAlt.lean` additionally imports the
project's `Problem26*` and `Dilogarithm` modules, which are not reproduced here.
The claims above were checked in the full development, not in this excerpt.

## Scope note

The write-up's Stage 1 (the creative-telescoping certificate and the closed form
for the inner sum) is presented as a derivation, not as a formalized result. Only
the seven scalar evaluations listed above were carried into Lean.
